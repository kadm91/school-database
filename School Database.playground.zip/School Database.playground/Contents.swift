import Foundation

//MARK: - Student and Teachers

struct Student {
    var name: String
    var favoriteTeacherID: Int
}

struct Teacher {
    var name: String
    var id: Int
    var email: String?
    var hairColor: String?
}

//MARK: - School Definition and Finding Teachers

struct School {
    var name: String
    var teachers: [Teacher]
    
    private func getTeacher(withID id: Int ) -> Teacher? {
        
         if let teacher = teachers.first(where: {$0.id == id}) {
             return teacher
         } else {
             return nil
         }
       
    }
    
    //MARK: - Displaying Information
    
    func printFavoriteTeacherInfo(for student: Student) {
        guard let teacher = getTeacher(withID: student.favoriteTeacherID) else {
            print("\nCouldn't find any teacher whit id \(student.favoriteTeacherID)")
            return
        }
        
        print ("\n\(student.name) favorite teacher is \(teacher.name)")
        
        if let hairColor = teacher.hairColor {
          print("Teacher hair color is \(hairColor)")
        }
        
        if let email = teacher.email {
            print( "Teacher email is \(email) ")
        } else {
            print("Teacher don't have an email accoutn")
        }
    }
}


//MARK: - Implementing our Models

let teachers: [Teacher] = [
    Teacher(
        name: "Mario",
        id: 12,
        email: "mario@gmail.com",
        hairColor: "blond"
    ),
    Teacher(
        name: "Jose",
        id: 19,
        email: "jose@gmail.com"
    ),
    Teacher(
        name: "Fransesca",
        id: 33,
        hairColor: "Red"
    ),
    Teacher(
        name: "Florencia",
        id: 111
    )
]

let eastBrocklyn = School(name: "East Brocklyn", teachers: teachers)

let student1 = Student(name: "Bon Jovi", favoriteTeacherID: 12)
let Student2 = Student(name: "Elvis", favoriteTeacherID: 19)
let student3 = Student(name: "Edi", favoriteTeacherID: 33)
let student4 = Student(name: "Patric", favoriteTeacherID: 111)
let student5 = Student(name: "Bob", favoriteTeacherID: 2)

eastBrocklyn.printFavoriteTeacherInfo(for: student1)
eastBrocklyn.printFavoriteTeacherInfo(for: Student2)
eastBrocklyn.printFavoriteTeacherInfo(for: student3)
eastBrocklyn.printFavoriteTeacherInfo(for: student4)
eastBrocklyn.printFavoriteTeacherInfo(for: student5)











